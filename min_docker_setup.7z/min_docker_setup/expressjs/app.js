require('dotenv');

const path = require('path');

const express = require('express');
const app = express();

const LISTEN_PORT = 3000;

app.get('/', (req, res) => res.send('hello world'));

app.listen(LISTEN_PORT, () => {
    console.log(`Listening on port ${LISTEN_PORT}`);
});
