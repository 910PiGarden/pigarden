import os
from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/py-test', methods=['GET'])
def index():
    return jsonify({'a': 'eric'})

@app.route('/user/<int:id>')
def user(id):
    return jsonify({'fname':'Eric','lname':'Moore', 'id' : id, 'r': 3})

if __name__ == '__main__':
    port = int(os.environ.get('PORT',5000))
    app.run(host='0.0.0.0',port=port)
