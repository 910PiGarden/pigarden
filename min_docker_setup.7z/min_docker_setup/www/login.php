<?php
require 'allowed_headers.php';
include './classes/JWToken.php';
include './classes/Database.php';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $host = $_ENV['MYSQL_HOST'];
    $dbname = $_ENV['MYSQL_DB'];
    $username = 'root'; //$_ENV['MYSQL_USER'];
    $password = 'rootpassword';//$_ENV['MYSQL_PASSWORD'];
    $jwtSecret = $_ENV['JWT_SECRET'];
    // get user input
    $post = json_decode(file_get_contents('php://input'), true);

    $dataBase = new Database($host,$dbname,$username,$password);
    $email = $post['email'];
    $password = $post['password'];

    $query = "SELECT * FROM testing_users WHERE email='$email'";

    // get hashed password from the database
    $user_data = $dataBase->select_statement($query);
    $user_data = json_decode($user_data,true);

    // verify hashed password against user password
    if(password_verify($password, $user_data[0]['password'])){
        
        // create token with database stuff.
        $jwt = new JWToken();

        // add user data to the token
        $jwt->createToken(['data' => $user_data[0], 'secret_key' => $jwtSecret]);
        // send token on success.
        echo json_encode(['success' => '', 'token' =>  $jwt->getToken()]);
    }else{
        echo json_encode(['error' => '', 'message' => 'invalid credentials!']);
    }

}else{
    echo json_encode(['error' => '']);
}

?>