<?php
// use an auto loader.
require 'allowed_headers.php';
require 'api/config/config.php';
require 'api/libs/bootStrap.php'; // the bootstrap that loads stuff.
require 'api/libs/controller.php'; // loads all controllers
require 'api/libs/model.php'; // loads all models.
require 'api/libs/view.php'; // loads all views.
require 'api/libs/database.php'; // loads database.

require './classes/JWToken.php';
// can wrap in if and check token.
// since all things are instantiated here
// we must use ?url=file_name/method_name/param1/param2.../param(n)
$environment = $_ENV['ENVIRONMENT'];

if ($environment == 'PROD') {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $jwtSecret = $_ENV['JWT_SECRET'];
        $post = json_decode(file_get_contents('php://input'), true);
        if (isset($post['token'])) {
            $token = $post['token'];
            $jwt = new JWToken();
            $jwt->createToken(['secret_key' => $jwtSecret]);
            $isValid = $jwt->isTokenValid($token);
            if ($isValid) {
                $app = new BootStrap(); // instantiate Bootstrap.
            } else {
                echo json_encode(['error' => '', 'message' => 'There is a problem']);
            }
        } else {
            echo json_encode(['error' => '', 'message' => 'There is a problem']);
        }
    } else {
        echo json_encode(['error' => '', 'message' => 'There is a problem']);
    }
} else if ($environment == 'DEV') {
    $app2 = new BootStrap();
}
