<?php
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');
    header('Access-Control-Allow-Methods: POST,GET');
    header('Access-Control-Allow-Headers: Access-Conntrol-Allow-Headers,Content-Type,Access-Control-Allow-Methods,Authorization, X-Requested-With');
?>