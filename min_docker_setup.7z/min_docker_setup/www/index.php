<?php
    echo '<h1>Hello World From: php_mysql_docker</h1>';   
    echo '<pre>';
    print_r($_ENV);
    print_r($_GET);
    echo '</pre>';
    //phpinfo();
?>