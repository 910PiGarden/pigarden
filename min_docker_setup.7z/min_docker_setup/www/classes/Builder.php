<?php
include 'Database.php';
class Builder{
    private $database;
    public function __construct($database){
        
    }

    public function buildDrugGroup($groupId){
        // check if in data base
       
    }

    public function xyz(){
    }

}
?>