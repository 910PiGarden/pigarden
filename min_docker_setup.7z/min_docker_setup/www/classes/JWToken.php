<?php
require './vendor/autoload.php';

use \Firebase\JWT\JWT;

class JWToken{
    
    private $secret_key; // secret key
    private $iss;
    private $iat;
    private $nbf;
    private $exp;
    private $aud;
    private $data;

    /**
     * 
     * @params $initialize an array of values to replace JWT payload values
     */
    public function __construct(){
         
    }

    public function createToken($initialize){
        $now = time();
        $now_plus_time = $now;
         
        $init_values = ['secret_key' => 'example_key',
            'iss' => 'localhost',
            'iat' => $now,
            'nbf' => $now_plus_time,
            'exp' =>  $now_plus_time + (60 * 60),
            'aud' => 'myusers',
            'data' => [ 'user_id' => 1]
        ];

        if(count($initialize) > 0 ){
            $init_values = array_merge($init_values,$initialize);
        }

        $this->secret_key = $init_values['secret_key'];
        $this->iss = $init_values['iss'];
        $this->iat = $init_values['iat'];
        $this->nbf = $init_values['nbf'];
        $this->exp = $init_values['exp'];
        $this->aud = $init_values['aud'];
        $this->data = $init_values['data'];
    }

    public function getToken(){
        $payload =[
            "iss" => $this->iss,
            "aud" => $this->aud,
            "iat" => $this->iat,
            "nbf" => $this->nbf,
            "exp" => $this->exp,
            "data" => $this->data
        ];

        $jwt = JWT::encode($payload, $this->secret_key);
        return $jwt;
    }

    public function isTokenValid($token){
        try{
            $decoded = JWT::decode($token, $this->secret_key, array('HS256'));
            return 1;
        }catch(Exception $e){
            return 0;
        }
        return 0;
    }

    public function getCurrentUserData($token){
        $decoded = JWT::decode($token,$this->secret_key, array('HS256'));
        $decoded_array = (array) $decoded;
        $data = json_encode($decoded_array['data']);
        $info = ['aud' => $decoded_array['aud'], 'data' => $data];
        return $info;
    }

    public function refreshToken($token){
        $decoded = JWT::decode($token,$this->secret_key, array('HS256'));
        $decoded_array = (array) $decoded;
        $data = json_encode($decoded_array['data']);
        $data = json_decode($data,true);
        $this->createToken([ 'secret_key' => $this->secret_key,'data' => $data]);
    }
}
?>