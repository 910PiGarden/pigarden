<?php
class Database{
    private $connection;
    public function __construct($host,$dbname,$username,$password){
        try{
            // connect to the db.
            $this->$connection = new PDO("mysql:host=$host;dbname=$dbname",$username,$password);
            $this->$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }catch( PDOException $e){
            echo 'Connection Error: ' . $e->getMessage();
        }
    }

    public function select_statement( $query_str ){
        $data = $this->$connection->query($query_str);
        return json_encode($data->fetchAll(PDO::FETCH_ASSOC));
    }

    public function select_with_prepare($query){
        $stmt = $this->$connection->prepare($query);
        $stmt->execute();
        $num = $stmt->rowCount();
        echo $num;

        if($num > 0){
            $data = [];
            $data['data'] =[];

            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                array_push($data['data'],$row);
            }
            return $data;
        }else{

        }

    }

}
?>