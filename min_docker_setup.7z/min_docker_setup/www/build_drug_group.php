<?php
    require 'allowed_headers.php';

    include './classes/Database.php';
    $host = $_ENV['MYSQL_HOST'];
    $dbname = $_ENV['MYSQL_DB'];
    $username = 'root'; //$_ENV['MYSQL_USER'];
    $password = $_ENV['MYSQL_ROOT_PASSWORD'];

    $dataBase = new Database($host,$dbname,$username,$password);
    

    $drugGroupQuery = 'SELECT group_id FROM drug_group';
    $drugGroupTable = json_decode($dataBase->select_statement($drugGroupQuery),true);
    for($i = 0; $i < count($drugGroupTable); $i++){
        $groupId = $drugGroupTable[$i]['group_id'];
        
        $patientQuery = "SELECT drug_id FROM drug_group_map WHERE group_id=$groupId";
        $drugGroupTable[$i]['drug'] = json_decode($dataBase->select_statement($patientQuery),true);
        $filename =  dirname(__FILE__) . DIRECTORY_SEPARATOR . 'json_files' .
                        DIRECTORY_SEPARATOR . 'skeleton_drug_group' .
                        DIRECTORY_SEPARATOR . $groupId . '.json';
        //file_put_contents ($filename, json_encode($drugGroupTable[$i]));
    }
    
    echo 'DONE';
?>