<?php
require 'classes/JWToken.php'; 
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $jwtSecret = $_ENV['JWT_SECRET'];
    $post = json_decode(file_get_contents('php://input'), true);
    if (isset($post['token'])) {
        $token = $post['token'];
        $jwt = new JWToken();
        $jwt->createToken(['secret_key' => $jwtSecret]);
        $isValid = $jwt->isTokenValid($token);
        if ($isValid) {
            // get new token
            $newToken = $jwt->refreshToken($token);
            echo json_encode(['success' => '', 'token' =>  $jwt->getToken()]);
        } else {
            echo json_encode(['error' => '', 'message' => 'There is a problem']);
        }
    } else {
        echo json_encode(['error' => '', 'message' => 'There is a problem']);
    }
} else {
    echo json_encode(['error' => '', 'message' => 'There is a problem']);
}
