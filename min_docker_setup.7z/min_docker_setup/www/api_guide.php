<?php
$api_guide = [
    [
        'title' => 'patients',
        'url'   => '/patient<br />/patient/[pid]',
        'params' => 'none: returns a list of patients<br />pid: as patient id gets a single patient',
        'type' => 'GET'
    ],
    [
        'title' => 'citations',
        'url'   => '/citations<br />/citations/[cid]',
        'params' => 'none: returns a list of citations<br />cid: as citation id gets a single citation',
        'type' => 'GET' 
    ],
    [
        'title' => 'login',
        'url'   => '/login',
        'params' => 'email: String, password: String',
        'type' => 'POST' 
    ],
    [
        'title' => 'refresh token',
        'url'   => '/refresh-token',
        'params' => 'token: String',
        'type' => 'POST' 
    ],
];

echo '<dl>';
for($i = 0; $i < count($api_guide); $i++){
    
        echo '<dt>';
            echo '<h3>' . $api_guide[$i]['title'] . '</h3>';
        echo '<dt>';
        echo '<dd>';
        echo '<h4>' . $api_guide[$i]['url'] . '</h4>';
        echo '<h5>' . $api_guide[$i]['params'] . '</h5>';
        echo '<h5>' . $api_guide[$i]['type'] . '</h5>';
        echo '<dd>';   
}
echo '<dl>';

// RewriteRule ^v1/test test.php [NC,L]

// RewriteRule ^v1/diagnoses/([0-9a-zA-Z_]+) diagnoses.php?search=$1 [NC,L]
// RewriteRule ^v1/diagnoses diagnoses.php [NC,L]

// RewriteRule ^v1/login login.php [NC,L]
// RewriteRule ^v1/refresh-token refresh_token.php [NC,L]

# api folder
// RewriteRule ^api/v1/([0-9a-zA-Z_/]+) api_index.php?url=$1 [NC,L]