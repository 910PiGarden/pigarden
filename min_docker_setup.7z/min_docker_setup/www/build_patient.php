<?php
    require 'allowed_headers.php';
    include './classes/Database.php';
    
    $host = $_ENV['MYSQL_HOST'];
    $dbname = $_ENV['MYSQL_DB'];
    $username = 'root'; //$_ENV['MYSQL_USER'];
    $password = 'rootpassword';//$_ENV['MYSQL_PASSWORD'];

    $dataBase = new Database($host,$dbname,$username,$password);
    

    $patientQuery = 'SELECT patient_id, program_id FROM patient';
    $patientTable = json_decode($dataBase->select_statement($patientQuery),true);
    for($i = 0; $i < count($patientTable); $i++){
        $patientId = $patientTable[$i]['patient_id'];
        
        $allergyQuery = "SELECT allergy_id FROM patient_allergy WHERE patient_id=$patientId";
        $patientTable[$i]['allergy'] = json_decode($dataBase->select_statement($allergyQuery),true);

        $consultQuery = "SELECT consult_id FROM patient_consult WHERE patient_id=$patientId";
        $patientTable[$i]['consult'] = json_decode($dataBase->select_statement($consultQuery),true);

        $diagnosisQuery = "SELECT diagnosis_id FROM patient_diagnosis WHERE patient_id=$patientId";
        $patientTable[$i]['diagnosis'] = json_decode($dataBase->select_statement($diagnosisQuery),true);

        $drugQuery = "SELECT drug_id FROM patient_drug WHERE patient_id=$patientId";
        $patientTable[$i]['drug'] = json_decode($dataBase->select_statement($drugQuery),true);

        $imageQuery = "SELECT image_id FROM patient_image WHERE patient_id=$patientId";
        $patientTable[$i]['image'] = json_decode($dataBase->select_statement($imageQuery),true);

        $orderQuery = "SELECT order_id, position FROM patient_order WHERE patient_id=$patientId";
        $patientTable[$i]['non_med_order'] = json_decode($dataBase->select_statement($orderQuery),true);

        $interviewQuery = "SELECT video_id FROM interview WHERE patient_id=$patientId";
        $patientTable[$i]['interview'] = json_decode($dataBase->select_statement($interviewQuery),true);

        $drugGroupQuery = "SELECT group_id FROM drug_group WHERE target_id=$patientId AND target_type='patient'";
        $patientTable[$i]['drug_group'] = json_decode($dataBase->select_statement($drugGroupQuery),true);
        //file_put_contents ( dirname(__FILE__) . DIRECTORY_SEPARATOR . 'json_files' . DIRECTORY_SEPARATOR . 'skeleton_patient' . DIRECTORY_SEPARATOR . $patientId . '.json', json_encode($patientTable[$i]));
    }

   /**
    *  program: patient_id, program_id
    *  patient_allergy: [] allergy_id
    *  patient_consult: [] consult_id
    *  patient_diagnosis: [] diagnosis_id
    *  patient_drug: [] drug_id
    *  patient_image: [] image_id
    *  patient_order: [] order_id
    *  interview: [] video_id
    *  
    *  drug_group: [] drug_id from drug || group_id from drug_group
    */

    echo 'DONE';
?>