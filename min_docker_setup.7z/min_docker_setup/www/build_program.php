<?php
    require 'allowed_headers.php';
    include './classes/Database.php';
    
    $host = $_ENV['MYSQL_HOST'];
    $dbname = $_ENV['MYSQL_DB'];
    $username = 'root'; //$_ENV['MYSQL_USER'];
    $password = 'rootpassword';//$_ENV['MYSQL_PASSWORD'];

    $dataBase = new Database($host,$dbname,$username,$password);
    

    $programQuery = 'SELECT program_id FROM program';
    $programTable = json_decode($dataBase->select_statement($programQuery),true);
    for($i = 0; $i < count($programTable); $i++){

        $programId = $programTable[$i]['program_id'];
        
        $citationQuery = "SELECT citation_id, cite_index FROM program_citation WHERE program_id=$programId";
        $programTable[$i]['citation'] = json_decode($dataBase->select_statement($citationQuery),true);

        $drugGroupQuery = "SELECT group_id FROM drug_group WHERE target_id=$programId AND target_type='program'";
        $programTable[$i]['drug_group'] = json_decode($dataBase->select_statement($drugGroupQuery),true);

        $learningObjectiveQuery = "SELECT objective_id FROM learning_objective WHERE program_id=$programId";
        $programTable[$i]['learning_objective'] = json_decode($dataBase->select_statement($learningObjectiveQuery),true);

        $patientQuery = "SELECT patient_id FROM patient WHERE program_id=$programId";
        $programTable[$i]['patient'] = json_decode($dataBase->select_statement($patientQuery),true);

        $filename =  dirname(__FILE__) . DIRECTORY_SEPARATOR . 'json_files' .
                        DIRECTORY_SEPARATOR . 'skeleton_program' .
                        DIRECTORY_SEPARATOR . $programId . '.json';
        //file_put_contents ($filename, json_encode($programTable[$i]));
    }
    echo 'DONE';
?>