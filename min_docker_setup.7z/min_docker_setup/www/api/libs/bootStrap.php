<?php

class BootStrap
{

        function __construct()
        {
                // echo 'Location: libs/bootStrap.php<br>';
                // explode the url from the get array.
                // this allows to get a class with a method.
                $url = isset($_GET['url']) ? $_GET['url'] : null; // get the url.
                $url = rtrim($url, '/');
                $url = explode('/', $url);
                if (empty($url[0])) {
                        // url[0] is empty include controllers to go to login page.
                        echo 'Hello';
                        die();
                }
                $file = './api/controllers/' . $url[0] . '.php';
                if (file_exists($file)) // check to see if the file exists
                {
                        require $file;  // if file exists require it.
                } else {
                        // if the file does not exist send it to error page.
                        //                            require 'controllers/error.php';
                        //                            $controller = new Error();
                        echo 'Houston we have a problem.<br/>' . $_GET['url'];
                        die(); // stop program from progressing on. FYI: can use return false;
                }

                // the require $file above is to instantiate the controller
                $controller = new $url[0]; // instantiate new controller.

                // if url[1] isset call method. FYI array[0] is the class,
                // array[1] is the method in the class, and array[2] to array[n] are the 
                // parameters in the class method;
                if (isset($url[4])) {
                        // use method with a parameter.
                        $controller->{$url[1]}($url[2], $url[3], $url[4]);
                } else if (isset($url[3])) {
                        // use method with a parameter.
                        $controller->{$url[1]}($url[2], $url[3]);
                } else if (isset($url[2])) {
                        // use method with a parameter.
                        $controller->{$url[1]}($url[2]);
                } else {
                        if (isset($url[1])) {
                                // use method without a parameter.
                                $controller->{$url[1]}();
                        } else {
                                $controller->index();
                        }
                }
        }
}
