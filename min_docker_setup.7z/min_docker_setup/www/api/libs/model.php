<?php

    class Model
    {

            public function __construct()
                    {
                    // by place the database in the base model
                    // all children will get a data base object.
                    $this->database = new Database();
                    $this->database->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
                    }
					
			public function get_db_data($sql)
			{
				$statement = $this->database->prepare($sql); // 
                $statement->execute();
                $statement->setFetchMode(PDO::FETCH_ASSOC); // set pdo object to fetch associative/named array only.
                $data = $statement->fetchAll();
                $statement->closeCursor();
                return $data;
			}

            /**
             * The create_insert function preps an array to be inserted
             * into a database.
             * @param type $array
             * @return type array keys = has all insert keys
             *                    vals =  has all values
             */
            public function create_insert($array)
                    {
                    $sponsor = array();
                    foreach ($array as $key => $value) {
							
                            if (!empty($value))
                            {
                                    if (is_numeric($value))
                                    {
                                            $sponsor[$key] = $value;
                                    } else
                                    {
                                            $sponsor[$key] = "'$value'";
                                    }
                            }
                    }

                    $keys = array_keys($sponsor);
                    $vals = array_values($sponsor);
                    $keys = implode(',', $keys);
                    $vals = implode(",", $vals);
                    return array('keys' => $keys, 'vals' => $vals);
                    }

            public function create_update($array)
                    {
                    $stuff = '';
					
                    foreach ($array as $key => $value) {
							if($value == '0'){
								$stuff .= "$key=$value,";
							}
                            if (!empty($value))
                            {
									
                                    if (is_numeric($value))
                                    {
                                            $stuff .= "$key=$value,";
                                    } else
                                    {
                                            $value = trim($value);
                                            $stuff .= "$key='$value',";
                                    }
                            }
                    }
                    return substr($stuff, 0, strlen($stuff) - 1);
                    }
    }
    