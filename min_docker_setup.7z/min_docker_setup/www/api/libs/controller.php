<?php

class Controller
{

	function __construct()
	{
		// this is the controller that all controllers
		// in the controllers folder inherit from.
		// echo 'Location: libs/controller.php';
		// the $this->view is a reference to libs/view.php
		$this->view = new View(); // stantiates view object.
	}

	/**
	 * The load_model function returns a model so that
	 * its db methods can be used. It assumes that the
	 * programmer has named its controllers properly.
	 * I.E: if the controller = index : model = modelname.php
	 * @param type $name model name
	 * @return type Model
	 */
	public function load_model($name)
	{

		$path = 'api/models/' . $name . '.php'; // create a path string.
		if (file_exists($path)) // see if path exists
		{
			require 'api/models/' . $name . '.php'; // require the model for children: auto.
			$model_name = $name; // see controller names to know models.
			$this->model = new $model_name();
			return $this->model;
		} else {
			echo 'There is no ' . $name . ' Model';
		}
	}

	public function load_form_control($name)
	{
		$path = 'form_controls/' . $name . '.php'; // create a path string.
		if (file_exists($path)) // see if path exists
		{
			require 'form_controls/' . $name . '.php';
			$fc = $name; // see controller names to know models.
			$this->form_control = new $fc();
			return $this->form_control;
		} else {
			echo 'There is no ' . $name . '_Model';
		}
	}
}
