<?php

    class View
    {

            function __construct()
                    {
//                    echo '<br/>Location: libs/view.php.<br/>';
                    }

            /**
             * The render function renders a view from
             * the views/$name folder.
             * @param type $name name of the view to be rendered.
             * 
             */
            public function render($name,$data = array())
                    {
                    extract($data);
                    // this takes us to the views folder.
                    require 'views/' . $name . '.php';
                    }

    }
    