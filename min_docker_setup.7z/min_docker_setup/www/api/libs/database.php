<?php

class Database extends PDO
{

        public function __construct()
        {
                $host = $_ENV['MYSQL_HOST'];
                $dbname = $_ENV['MYSQL_DB'];
                $username = 'root'; //$_ENV['MYSQL_USER'];
                $password = $_ENV['MYSQL_ROOT_PASSWORD'];
                parent::__construct(
                        'mysql:dbname='
                                . $dbname
                                . ';host=' . $host,
                                $username,
                                $password
                );
        }
}
