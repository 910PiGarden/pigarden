<?php

class Diagnosis extends Controller
{

    function __construct()
    {
        parent::__construct();
        $this->diagnosis_model = $this->load_model('diagnosis_model');
    }

    function index()
    {
        $this->paginate(1,0);
    }

    function get_diagnosis($id){
        $dbData = $this->diagnosis_model->get_diagnosis($id);
        $data = [
            'data'  => $dbData
        ];
        echo json_encode($data);
    }
    // $direction = 0 to go back| 1 to go forward.
    function paginate($direction = 1, $id = 0){
        $dbData = [];
        if($direction){
            $dbData = $this->diagnosis_model->paginate_forward($id);
        }else{
            $dbData = $this->diagnosis_model->paginate_backward($id);
        }
        
        $min = $this->diagnosis_model->get_min_id()[0];
        $max = $this->diagnosis_model->get_max_id()[0];

        $data = [
            'first_page' => 0,
            'last_page'  => 100,
            'first_id' => $min['min_id'],
            'last_id' => $max['max_id'],
            'data'  => $dbData
        ];

        if(count($dbData)){
            $data = [
                'first_page' => $dbData[0]['diagnosis_id'],
                'last_page'  => $dbData[count($dbData) - 1]['diagnosis_id'],
                'first_id' => $min['min_id'],
                'last_id' => $max['max_id'],
                'data'  => $dbData
            ];
        }
        
        echo json_encode($data);
    }

    function search($sSearch = 'lead'){
        $dbData = $this->diagnosis_model->search($sSearch);
        $min = $this->diagnosis_model->get_min_id()[0];
        $max = $this->diagnosis_model->get_max_id()[0];
        $data = [
            'first_page' => 0,
            'last_page'  => 100,
            'first_id' => $min['min_id'],
            'last_id' => $max['max_id'],
            'data'  => $dbData
        ];

        if(count($dbData)){
            $data = [
                'first_page' => $dbData[0]['diagnosis_id'],
                'last_page'  => $dbData[count($dbData) - 1]['diagnosis_id'],
                'first_id' => $min['min_id'],
                'last_id' => $max['max_id'],
                'data'  => $dbData
            ];
        }

        echo json_encode($data);
    }
}
