<?php

class MyTest extends Controller
{

    function __construct()
    {
        parent::__construct();
        //$this->drug_model = $this->load_model('drug_model');
        // this is for cme
        $this->checkInfile = array(
            // start program details panel
            'sProgram' => array(
                'panelName' => 'program details',
                'label' => 'program id',
                'panelIndex' => 0,
                'key' => 'sProgram',
                'programTypeId' => 3, // type_id
                'fieldType' => 'text',
                'programSubType' => NULL, // subtype
                'defaultValue' => '',
            ),
            'sCondition' => array(
                'panelName' => 'program details',
                'panelIndex' => 1,
                'label' => 'condition',
                'key' => 'sCondition',
                'programTypeId' => 3, // type_id
                'fieldType' => 'text',
                'programSubType' => NULL, // subtype
                'defaultValue' => '',
            ),
            'iLaunchDate' => array(
                'panelName' => 'program details',
                'label' => 'launch date',
                'panelIndex' => 2,
                'key' => 'iLaunchDate',
                'programTypeId' => 3, // type_id
                'fieldType' => 'calendar',
                'programSubType' => NULL, // subtype
                'defaultValue' => '',
            ),
            'bRetired' => array(
                'panelName' => 'program details',
                'label' => 'retired',
                'panelIndex' => 3,
                'key' => 'bRetired',
                'programTypeId' => 3, // type_id
                'fieldType' => 'checkbox',
                'programSubType' => NULL, // subtype
                'defaultValue' => '0',
            ),
            'bOUSProgram' => array(
                'panelName' => 'program details',
                'label' => 'mark as ous template',
                'panelIndex' => 4,
                'key' => 'bOUSProgram',
                'programTypeId' => 3, // type_id
                'fieldType' => 'checkbox',
                'programSubType' => NULL, // subtype
            ),
            'iCGMode' => array(
                'panelName' => 'program details',
                'panelIndex' => 5,
                'label' => 'guidance mode',
                'key' => 'iCGMode',
                'programTypeId' => 3, // type_id
                'fieldType' => 'select',
                'programSubType' => NULL, // subtype
                'options' => [
                    [ 'value' => '-1', 'text' => 'select guidance mode'],
                    [ 'value' => '0', 'text' => 'show everywhere'],
                    [ 'value' => '2', 'text' => 'show at fcc and case review'],
                    [ 'value' => '3', 'text' => 'show at case review'],
                    [ 'value' => '1', 'text' => 'never show'],
                ],
            ),
            'sTempUnit' => array(
                'panelName' => 'program details',
                'label' => 'temperature unit',
                'panelIndex' => 6,
                'key' => 'sTempUnit',
                'programTypeId' => 3, // type_id
                'fieldType' => 'select',
                'programSubType' => NULL, // subtype
                'options' => [
                    [ 'value' => '-1', 'text' => 'select a value'],
                    [ 'value' => 'f', 'text' => 'fahrenheit (f)'],
                    [ 'value' => 'c', 'text' => 'celsius (c)'],
                ],
            ),
            'sSimVersion' => array(
                'panelName' => 'program details',
                'panelIndex' => 7,
                'key' => 'sSimVersion',
                'label' => 'forward to simulator type',
                'programTypeId' => 3, // type_id
                'fieldType' => 'select',
                'programSubType' => NULL, // subtype
                'options' => [
                    [ 'value' => '4.0-cme', 'text' => 'cme'],
                    [ 'value' => '4.0-promo', 'text' => 'promo'],
                    [ 'value' => '4.0-editorial', 'text' => 'editorial'],
                    [ 'value' => '4.0-partners', 'text' => 'partners'],
                    [ 'value' => '3.5-cme', 'text' => 'legacy cme'],
                    [ 'value' => '3.5-promo', 'text' => 'legacy promo'],
                    [ 'value' => '3.5-editorial', 'text' => 'legacy partners'],
                ],
            ),
            // end program details panel

            // start completion modal
            'sPostSimTitle' => array(
                'panelName' => 'case completion modal',
                'label' => 'box title',
                'panelIndex' => 0,
                'key' => 'sPostSimTitle',
                'programTypeId' => 3, // type_id
                'fieldType' => 'text',
                'programSubType' => NULL, // subtype
            ),
            'sPostSimContent' => array(
                'panelName' => 'case completion modal',
                'label' => 'box message',
                'panelIndex' => 1,
                'key' => 'sPostSimContent',
                'programTypeId' => 3, // type_id
                'fieldType' => 'text',
                'programSubType' => NULL, // subtype
            ),
            'sPostSimBtnLabel'  => array(
                'panelName' => 'case completion modal',
                'label' => 'button label',
                'panelIndex' => 2,
                'key' => 'sPostSimBtnLabel',
                'programTypeId' => 3, // type_id
                'fieldType' => 'text',
                'programSubType' => NULL, // subtype
            ),
            // end completion modal

            // start Medscape
            'sProgramName' => array(
                'panelName' => 'medscape',
                 'label' => 'title of program',
                'panelIndex' => 0,
                'key' => 'sProgramName',
                'programTypeId' => 3, // type_id
                'fieldType' => 'text',
                'programSubType' => NULL, // subtype
            ),
            'sLanguage' => array(
                'panelName' => 'medscape',
                'label' => 'program language',
                'panelIndex' => 1,
                'key' => 'sLanguage',
                'programTypeId' => 3, // type_id
                'fieldType' => 'select',
                'programSubType' => NULL, // subtype
                'options' => [
                    [ 'value' => '-1', 'text' => 'select language'],
                    [ 'value' => 'en', 'text' => 'english'],
                    [ 'value' => 'es', 'text' => 'spnish'],
                    [ 'value' => 'it', 'text' => 'italian'],
                    [ 'value' => 'de', 'text' => 'german'],
                    [ 'value' => 'fr', 'text' => 'french'],
                ],
            ),
            'sGuidelinesTitle' => array(
                'panelName' => 'medscape',
                'label' => 'guidelines notice title',
                'panelIndex' => 2,
                'key' => 'sGuidelinesTitle',
                'programTypeId' => 3, // type_id
                'fieldType' => 'text',
                'programSubType' => NULL, // subtype
            ),
            'sWelcomeMsgTitle' => array(
                'panelName' => 'medscape',
                'label' => 'cme welcome mesage',
                'panelIndex' => 3,
                'key' => 'sWelcomeMsgTitle',
                'programTypeId' => 3, // type_id
                'fieldType' => 'text',
                'programSubType' => NULL, // subtype
            ),

            
            'sArticleUrl' => array(
                'panelName' => 'medscape',
                'label' => 'medscape article url',
                'key' => 'sArticleUrl',
                'panelIndex' => 4,
                'programTypeId' => 3, // type_id
                'fieldType' => 'text',
                'programSubType' => NULL, // subtype
            ),
            'sSalesforceNumber' => array(
                'panelName' => 'medscape',
                'label' => 'medscape article url',
                'key' => 'sSalesforceNumber',
                'panelIndex' => 5,
                'programTypeId' => 3, // type_id
                'fieldType' => 'text',
                'programSubType' => NULL, // subtype
            ),
            'sTestDisclaimerTitle' => array(
                'panelName' => 'medscape',
                'label' => 'medscape article url',
                'key' => 'sSalesforceNumber',
                'fieldType' => 'text',

                'panelIndex' => 5,
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sQuestUrl' => array(
                'panelName' => 'medscape',
                'label' => 'medscape questionnaire url',
                'fieldType' => 'text',
                
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sTheme' => array(
                'panelName' => 'medscape',
                'label' => 'theme',
                'fieldType' => 'select',
                'options' => [
                    [ 'value' => '-1', 'text' => 'select item'],
                    [ 'value' => 'default', 'text' => 'default theme'],
                    [ 'value' => 'light', 'text' => 'light theme'],
                ],
                
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sGuidelines' => array(
                'panelName' => 'medscape',
                'label' => 'guidelines notice',
                'fieldType' => 'wysiwyg',
                
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sWelcomeMsg' => array(
                'panelName' => 'medscape',
                'label' => 'cme welcome message',
                'fieldType' => 'wysiwyg',
                
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sTestDisclaimer' => array(
                'panelName' => 'medscape',
                'label' => 'test disclaimer',
                'fieldType' => 'wysiwyg',
                
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            
            'bHideProductInfo' => array(
                'panelName' => 'medscape',
                'label' => 'hide product info section',
                'fieldType' => 'checkbox',
                
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bHideDosingInfo' => array(
                'panelName' => 'medscape',
                'label' => 'hide dosing info section',
                'fieldType' => 'checkbox',
                
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bHideDCI' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bHideDDI' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bHideDosageRange' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bHideHeadshot' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bShowImperialMeasuments' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bHidePrescriptionPad' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bShowHistoricalReports' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bEnableTestGroups' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bDownloadLiterature' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bSkipWaitingRoom' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bPromoted' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bDisableGraphs' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bDisableDrugs' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'bGlobalProgram' => array(
                'panelName' => 'medscape',
                'fieldType' => 'checkbox',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            // end Medscape

            // start learning objectives special
            'aObjectives'=> array(
                'panelName' => 'learning objectives',
                'label' => 'test disclaimer',
                 'fields' => [
                     [
                        'type' => 'wysiwyg',
                        'name' => '',
                        'weight' => 1
                    ],
                 ],
                
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            // end learning objectives

            // start literature review
            'sLiteratureReview' => array(
                'panelName' => 'literature review',
                'label' => 'literature review',
                'fieldType' => 'wysiwyg',
                
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            // end literature review

            // start custom css
            'sCustomCss' => array(
                'panelName' => 'custom css rules',
                'label' => 'custom css',
                'fieldType' => 'wysiwyg',
                
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            // end custom css

            // start guidance helpers
            'sGuidanceInfo' => array(
                'panelName' => 'guidance helpers',
                'fieldType' => 'text',
                'icon' => 'info',
                'label' => 'custom css',
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sGuidanceAppropriate' => array(
                'panelName' => 'guidance helpers',
                'fieldType' => 'text',
                'icon' => 'appropriate',
                'label' => 'custom css',
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sGuidanceWarning' => array(
                'panelName' => 'guidance helpers',
                'fieldType' => 'text',
                'icon' => 'warning',
                'label' => 'custom css',
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sGuidanceError' => array(
                'panelName' => 'guidance helpers',
                'fieldType' => 'text',
                'icon' => 'error',
                'label' => 'custom css',
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sGuidanceMistake' => array(
                'panelName' => 'guidance helpers',
                'fieldType' => 'text',
                'icon' => 'mistake',
                'label' => 'custom css',
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sGuidanceContraindicated' => array(
                'panelName' => 'guidance helpers',
                'fieldType' => 'text',
                'icon' => 'contraindicated',
                'label' => 'custom css',
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sGuidanceDosage' => array(
                'panelName' => 'guidance helpers',
                'fieldType' => 'text',
                'icon' => 'dosage',
                'label' => 'custom css',
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sGuidanceReview' => array(
                'panelName' => 'guidance helpers',
                'fieldType' => 'text',
                'icon' => 'review',
                'label' => 'custom css',
                'key' => 'sSalesforceNumber', // keys
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            // end guidance helpers

            // start survey
            'sSurveyQuestion' => array(
                'panelName' => 'start survey',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'aSurveyOptions' => array(
                'panelName' => 'start survey',
                'fieldType' => 'combo',
                'options' => [],

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            // end survey

            /* simulation sections: see page 5 this is special and different. */

            // start simulation subsections
            'sIntroHpiTitle' => array(
                'panelName' => 'simulation subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sIntroFamilySocialTitle' => array(
                'panelName' => 'simulation subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sIntroPhysicalExamTitle' => array(
                'panelName' => 'simulation subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sOrdersMedicationTitle' => array(
                'panelName' => 'simulation subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sOrdersNonMedicationOrdersTitle' => array(
                'panelName' => 'simulation subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            // end simulation subsections
            
            /* chart sections: see page 7 this is special and different. */

            // start chart subsections
            'sChartCaseDescriptionTitle' => array(
                'panelName' => 'chart subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sChartPastVisitsTitle' => array(
                'panelName' => 'chart subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sChartPastTestsTitle' => array(
                'panelName' => 'chart subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sChartConditionHistoryTitle' => array(
                'panelName' => 'chart subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sChartMedicationHistoryTitle' => array(
                'panelName' => 'chart subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sChartTodayTestsTitle' => array(
                'panelName' => 'chart subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sChartTodayDiagnosesTitle' => array(
                'panelName' => 'chart subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sChartTodayOrdersTitle' => array(
                'panelName' => 'chart subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sChartTodayOtherOrdersTitle' => array(
                'panelName' => 'chart subsections',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            // end chart subsections

            // start case review labels
            'sClosingLabel' => array(
                'panelName' => 'case review',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sLiteratureLabel' => array(
                'panelName' => 'case review',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sPerformanceLabel' => array(
                'panelName' => 'case review',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            'sPeerLabel' => array(
                'panelName' => 'case review',
                'fieldType' => 'text',
                

                'label' => 'hide drug/condition interaction ', // description
                'key' => 'sSalesforceNumber', // name
                'panelIndex' => 5, // get from index
                'programTypeId' => 3, // type_id
                'programSubType' => NULL, // subtype
            ),
            // end case review labels
            
        );

        $this->cmeInOrder  = [
            'sProgram',
            'sCondition',
            'iLaunchDate',
            'bRetired',
            'bOUSProgram',
            'iCGMode',
            'sTempUnit',
            'sSimVersion',
            // end program details panel

            // start completion modal
            'sPostSimTitle' ,
            'sPostSimContent' ,
            'sPostSimBtnLabel' ,
            // end completion modal

            // start Medscape
            'sProgramName' ,
            'sLanguage' ,
            'sGuidelinesTitle' ,
            'sWelcomeMsgTitle' ,
            'sArticleUrl',
            'sSalesforceNumber' ,
            'sTestDisclaimerTitle' ,
            'sQuestUrl' ,
            'sTheme' ,
            'sGuidelines' ,
            'sWelcomeMsg' ,
            'sTestDisclaimer' ,
            'bHideProductInfo' ,
            'bHideDosingInfo' ,
            'bHideDCI' ,
            'bHideDDI' ,
            'bHideDosageRange' ,
            'bHideHeadshot' ,
            'bShowImperialMeasuments' ,
            'bHidePrescriptionPad' ,
            'bShowHistoricalReports' ,
            'bEnableTestGroups' ,
            'bDownloadLiterature' ,
            'bSkipWaitingRoom' ,
            'bPromoted' ,
            'bDisableGraphs' ,
            'bDisableDrugs' ,
            'bGlobalProgram' ,
            // end Medscape

            // start learning objectives
            'aObjectives',
            // end learning objectives

            // start literature review
            'sLiteratureReview' ,
            // end literature review

            // start custom css
            'sCustomCss' ,
            // end custom css

            // start guidance helpers
            'sGuidanceInfo' ,
            'sGuidanceAppropriate' ,
            'sGuidanceWarning' ,
            'sGuidanceError' ,
            'sGuidanceMistake' ,
            'sGuidanceContraindicated' ,
            'sGuidanceDosage' ,
            'sGuidanceReview' ,
            // end guidance helpers

            // start survey
            'sSurveyQuestion' ,
            'aSurveyOptions' ,
            // end survey

            /* simulation sections: see page 5 this is special and different. */

            // start simulation subsections
            'sIntroHpiTitle' ,
            'sIntroFamilySocialTitle' ,
            'sIntroPhysicalExamTitle' ,
            'sOrdersMedicationTitle' ,
            'sOrdersNonMedicationOrdersTitle' ,
            // end simulation subsections
            
            /* chart sections: see page 7 this is special and different. */

            // start chart subsections
            'sChartCaseDescriptionTitle' ,
            'sChartPastVisitsTitle' ,
            'sChartPastTestsTitle' ,
            'sChartConditionHistoryTitle' ,
            'sChartMedicationHistoryTitle' ,
            'sChartTodayTestsTitle' ,
            'sChartTodayDiagnosesTitle' ,
            'sChartTodayOrdersTitle' ,
            'sChartTodayOtherOrdersTitle' ,
            // end chart subsections

            // start case review labels
            'sClosingLabel' ,
            'sLiteratureLabel' ,
            'sPerformanceLabel' ,
            'sPeerLabel' ,
        ];

        $this->cmeIndexOrder  = [
            '0',
            '1',
            '2',
            '3',
            '4',
            '5',
            '6',
            '7',
            // end program details panel

            // start completion modal
            '0' ,
            '1' ,
            '2' ,
            // end completion modal

            // start Medscape
            '0' ,
            '1' ,
            '2' ,
            '3' ,
            '4',
            '5' ,
            '6' ,
            '7' ,
            '8' ,
            '9' ,
            '10' ,
            '11' ,
            '12' ,
            '13' ,
            '14' ,
            '15' ,
            '16' ,
            '17' ,
            '18' ,
            '19' ,
            '20' ,
            '21' ,
            '22' ,
            '23' ,
            '24' ,
            '25' ,
            '26' ,
            '27' ,
            // end Medscape

            // start learning objectives
            '0',
            // end learning objectives

            // start literature review
            '0' ,
            // end literature review

            // start custom css
            '0' ,
            // end custom css

            // start guidance helpers
            '0' ,
            '1' ,
            '2' ,
            '3' ,
            '4' ,
            '5' ,
            '6' ,
            '7' ,
            // end guidance helpers

            // start survey
            '0' ,
            '1' ,
            // end survey

            /* simulation sections: see page 5 this is special and different. */

            // start simulation subsections
            '0' ,
            '1' ,
            '2' ,
            '3' ,
            '4' ,
            // end simulation subsections
            
            /* chart sections: see page 7 this is special and different. */

            // start chart subsections
            '0' ,
            '1' ,
            '2' ,
            '3' ,
            '4' ,
            '5' ,
            '6' ,
            '7' ,
            '8' ,
            // end chart subsections

            // start case review labels
            '0' ,
            '1' ,
            '2' ,
            '3' ,
        ];
        $this->checkInfileOld = array(
            // start program details panel
            'sProgram' => false,
            'sCondition' => false,
            'iLaunchDate' => false,
            'bRetired' => false,
            'bOUSProgram' => false,
            'iCGMode' => false,
            'sTempUnit' => false,
            'sSimVersion' => false,
            // end program details panel

            // start completion modal
            'sPostSimTitle' => false,
            'sPostSimContent' => false,
            'sPostSimBtnLabel' => false,
            // end completion modal

            // start Medscape
            'sProgramName' => false,
            'sLanguage' => false,
            'sGuidelinesTitle' => false,
            'sWelcomeMsgTitle' => false,
            'sArticleUrl' => false,
            'sSalesforceNumber' => false,
            'sTestDisclaimerTitle' => false,
            'sQuestUrl' => false,
            'sTheme' => false,
            'sGuidelines' => false,
            'sWelcomeMsg' => false,
            'sTestDisclaimer' => false,
            'bHideProductInfo' => false,
            'bHideDosingInfo' => false,
            'bHideDCI' => false,
            'bHideDDI' => false,
            'bHideDosageRange' => false,
            'bHideHeadshot' => false,
            'bShowImperialMeasuments' => false,
            'bHidePrescriptionPad' => false,
            'bShowHistoricalReports' => false,
            'bEnableTestGroups' => false,
            'bDownloadLiterature' => false,
            'bSkipWaitingRoom' => false,
            'bPromoted' => false,
            'bDisableGraphs' => false,
            'bDisableDrugs' => false,
            'bGlobalProgram' => false,
            // end Medscape

            // start learning objectives
            'aObjectives'=> false,
            // end learning objectives

            // start literature review
            'sLiteratureReview' => false,
            // end literature review

            // start custom css
            'sCustomCss' => false,
            // end custom css

            // start guidance helpers
            'sGuidanceInfo' => false,
            'sGuidanceAppropriate' => false,
            'sGuidanceWarning' => false,
            'sGuidanceError' => false,
            'sGuidanceMistake' => false,
            'sGuidanceContraindicated' => false,
            'sGuidanceDosage' => false,
            'sGuidanceReview' => false,
            // end guidance helpers

            // start survey
            'sSurveyQuestion' => false,
            'aSurveyOptions' => false,
            // end survey

            /* simulation sections: see page 5 this is special and different. */

            // start simulation subsections
            'sIntroHpiTitle' => false,
            'sIntroFamilySocialTitle' => false,
            'sIntroPhysicalExamTitle' => false,
            'sOrdersMedicationTitle' => false,
            'sOrdersNonMedicationOrdersTitle' => false,
            // end simulation subsections
            
            /* chart sections: see page 7 this is special and different. */

            // start chart subsections
            'sChartCaseDescriptionTitle' => false,
            'sChartPastVisitsTitle' => false,
            'sChartPastTestsTitle' => false,
            'sChartConditionHistoryTitle' => false,
            'sChartMedicationHistoryTitle' => false,
            'sChartTodayTestsTitle' => false,
            'sChartTodayDiagnosesTitle' => false,
            'sChartTodayOrdersTitle' => false,
            'sChartTodayOtherOrdersTitle' => false,
            // end chart subsections

            // start case review labels
            'sClosingLabel' => false,
            'sLiteratureLabel' => false,
            'sPerformanceLabel' => false,
            'sPeerLabel' => false,
            // end case review labels
            
        );
    }

    function cme()
    {
        $handle = @fopen("myfields.txt", "r");
        $count = 0;
        $headers = [];
        $data = [];
        if ($handle) {
            while (($buffer = fgets($handle, 4096)) !== false) {
                if($count == 0){
                    $headers = explode(';',$buffer);
                    $count += 1;
                    continue;
                }
                $values = explode(';',$buffer);
                if(count($headers) == count($values)){

                    $info = [];
                    for($i = 0; $i < count($headers); $i++){
                        $key = trim($headers[$i],' ');
                        $value = trim($values[$i],' ');
                        $info[$key] = $value;
                    }
                    array_push ( $data, $info );
                }
                //echo $buffer;
                $count += 1; 
            }
            if (!feof($handle)) {
                echo "Error: unexpected fgets() fail\n";
            }
            fclose($handle);
            $dan = $this->checkInfile;
            //print_r($data);

            // get the associated data from data keys
            for($i = 0; $i < count($data); $i++){
                $key = $data[$i]['name'];
                $label = $data[$i]['description'];
                $programTypeId = $data[$i]['type_id'];
                $programSubType = $data[$i]['subtype'];
                $defaultValue = $data[$i]['default_value'];
                if (array_key_exists($key,$dan)){
                    $dan[$key]['key'] = $key;
                    $dan[$key]['label'] = $label;
                    $dan[$key]['programTypeId'] = $programTypeId;
                    $dan[$key]['programSubType'] = $programSubType;
                    $dan[$key]['defaultValue'] = $defaultValue;
                }

            }


            $newInfo = [];
            $keysToKeep = ['label', 'key', 'fieldType', 'defaultValue', 'options'];
            for( $i = 0; $i < count($this->cmeInOrder); $i++){
                $key = $this->cmeInOrder[$i];
                $index = $this->cmeIndexOrder[$i];
                if(array_key_exists($key,$dan)){
                    $dan[$key]['panelIndex'] = $index;
                }
                $newInfo[$dan[$key]['panelName']]['panelName'] = $dan[$key]['panelName'];
                
                $newInfo[$dan[$key]['panelName']]['slug'] = str_replace(' ', '-', strtolower($dan[$key]['panelName']));
                $keysToKeepInfield = [];
                for($x = 0; $x < count($keysToKeep); $x++){
                    $currKey = $keysToKeep[$x];
                    if (array_key_exists($currKey,$dan[$key])){
                        $keysToKeepInfield[$currKey] = $dan[$key][$currKey];
                    }
                    
                }
                $newInfo[$dan[$key]['panelName']]['fields'][$index] = $keysToKeepInfield;
 
            }

            $jsonData = [];
            $jsonKeys = array_keys ($newInfo);
            for( $i = 0; $i < count($jsonKeys); $i++){
                //print_r($newInfo[$jsonKeys[$i]]);
                array_push($jsonData,$newInfo[$jsonKeys[$i]]);
            }
            
            //print_r($jsonData);
            echo json_encode($jsonData);
        }
    }
}