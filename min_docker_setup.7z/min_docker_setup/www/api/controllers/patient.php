<?php

class Patient extends Controller
{

    function __construct()
    {
        parent::__construct();
        $this->patient_model = $this->load_model('patient_model');
    }

    function index()
    {
        $this->paginate(1,0);
    }

    function get_patient($id){
        $dbData = $this->patient_model->get_patient($id);
        $data = [
            'data'  => $dbData
        ];
        echo json_encode($data);
    }
    // $direction = 0 to go back| 1 to go forward.
    function paginate($direction = 1, $id = 0){
        $dbData = [];
        if($direction){
            $dbData = $this->patient_model->paginate_forward($id);
        }else{
            $dbData = $this->patient_model->paginate_backward($id);
        }
        
        $min = $this->patient_model->get_min_id()[0];
        $max = $this->patient_model->get_max_id()[0];
        if(count($dbData)){
            $data = [
                'first_page' => $dbData[0]['patient_id'],
                'last_page'  => $dbData[count($dbData) - 1]['patient_id'],
                'first_id' => $min['min_id'],
                'last_id' => $max['max_id'],
                'data'  => $dbData
            ];
            echo json_encode($data);
            die;
        }
        $data = [
            'first_page' => 0,
            'last_page'  => 100,
            'first_id' => $min['min_id'],
            'last_id' => $max['max_id'],
            'data'  => $dbData
        ];
        echo json_encode($data);
    }
}
?>