<?php

class Citation extends Controller
{

    function __construct()
    {
        parent::__construct();
        $this->citation_model = $this->load_model('citation_model');
    }

    function index()
    {
        $this->paginate(1,0);
    }

    function get_citation($id){
        $dbData = $this->citation_model->get_citation($id);
        $data = [
            'data'  => $dbData
        ];
        echo json_encode($data);
    }
    // $direction = 0 to go back| 1 to go forward.
    function paginate($direction = 1, $id = 0){
        $dbData = [];
        if($direction){
            $dbData = $this->citation_model->paginate_forward($id);
        }else{
            $dbData = $this->citation_model->paginate_backward($id);
        }
        
        $min = $this->citation_model->get_min_id()[0];
        $max = $this->citation_model->get_max_id()[0];

        $data = [
            'first_page' => 0,
            'last_page'  => 100,
            'first_id' => $min['min_id'],
            'last_id' => $max['max_id'],
            'data'  => $dbData
        ];

        if(count($dbData)){
            $data = [
                'first_page' => $dbData[0]['citation_id'],
                'last_page'  => $dbData[count($dbData) - 1]['citation_id'],
                'first_id' => $min['min_id'],
                'last_id' => $max['max_id'],
                'data'  => $dbData
            ];
        }
        
        echo json_encode($data);
    }

    public function citations_by_program($iProgramId){
        $dbData = $this->citation_model->citations_by_program($iProgramId, 150);
        echo json_encode(['data' => $dbData]);
    }
}