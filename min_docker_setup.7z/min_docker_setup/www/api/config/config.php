<?php
/**
Eastern Time    America/New_York
Central Time    America/Chicago
Mountain Time   America/Denver
Mountain Time (no DST) America/Phoenix
Pacific Time    America/Los_Angeles
Alaska Time America/Anchorage
Hawaii-Aleutian America/Adak
Hawaii-Aleutian Time (no DST) Pacific/Honolulu
**/
// define email data.
define('CURRENT_TIME_ZONE','America/New_York');
?>				
    