<?php

class Citation_Model extends Model
{

    function __construct()
    {
        parent::__construct();
    }

    public function get_citation($id)
    {
        $statement = $this->database->prepare("SELECT *, IF(citation_id > 0, citation_id, citation_id) AS id  FROM citation WHERE citation_id=$id");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function paginate_forward($id = 0)
    {
        $statement = $this->database->prepare("SELECT *, IF(citation_id > 0, citation_id, citation_id) AS id FROM citation WHERE citation_id >= $id LIMIT 50");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function paginate_backward($id)
    {
        $statement = $this->database->prepare("SELECT *, IF(citation_id > 0, citation_id, citation_id) AS id FROM citation WHERE citation_id <= $id LIMIT 50");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function get_min_id(){
        $statement = $this->database->prepare("SELECT MIN(citation_id) AS min_id FROM citation");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function get_max_id(){
        $statement = $this->database->prepare("SELECT MAX(citation_id) AS max_id FROM citation");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function citations_by_program($iProgramId, $limit = 100){
        $query = "SELECT *, IF(citation_id > 0, citation_id, citation_id) AS id FROM citation WHERE program_id=$iProgramId LIMIT $limit";
        $statement = $this->database->prepare($query);
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }
}