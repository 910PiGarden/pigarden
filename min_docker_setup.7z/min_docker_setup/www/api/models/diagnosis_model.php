<?php

class Diagnosis_Model extends Model
{

    function __construct()
    {
        parent::__construct();
    }

    public function get_diagnosis($id)
    {
        $statement = $this->database->prepare("SELECT *, IF(diagnosis_id > 0, diagnosis_id, diagnosis_id) AS id  FROM diagnosis WHERE diagnosis_id=$id");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function paginate_forward($id = 0)
    {
        $statement = $this->database->prepare("SELECT *, IF(diagnosis_id > 0, diagnosis_id, diagnosis_id) AS id FROM diagnosis WHERE diagnosis_id >= $id LIMIT 50");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function paginate_backward($id)
    {
        $statement = $this->database->prepare("SELECT *, IF(diagnosis_id > 0, diagnosis_id, diagnosis_id) AS id FROM diagnosis WHERE diagnosis_id <= $id LIMIT 50");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function get_min_id(){
        $statement = $this->database->prepare("SELECT MIN(diagnosis_id) AS min_id FROM diagnosis");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function get_max_id(){
        $statement = $this->database->prepare("SELECT MAX(diagnosis_id) AS max_id FROM diagnosis");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function search($sSearch, $limit = 50)
    {   
        $query = "SELECT *, IF(diagnosis_id > 0, diagnosis_id, diagnosis_id) AS id FROM diagnosis WHERE all_patients=1 AND slug LIKE '%$sSearch%' LIMIT $limit";
        $statement = $this->database->prepare($query);
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function patient_diagnoses($iPatientId){
        $query =<<<MSG
        SELECT d.*, pd.* 
        FROM diagnosis AS d, patient_diagnosis AS pd 
        WHERE d.diagnosis_id=pd.diagnosis_id  
        AND pd.patient_id=$iPatientId
        ";
        MSG;
    }
}
