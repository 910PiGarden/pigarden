<?php

class Drug_Model extends Model
{

    function __construct()
    {
        parent::__construct();
    }

    public function get_drug($id)
    {
        $statement = $this->database->prepare("SELECT *, IF(drug_id > 0, drug_id, drug_id) AS id  FROM drug WHERE drug_id=$id");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function paginate_forward($id = 0)
    {
        $statement = $this->database->prepare("SELECT *, IF(drug_id > 0, drug_id, drug_id) AS id FROM drug WHERE drug_id >= $id LIMIT 50");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function paginate_backward($id)
    {
        $statement = $this->database->prepare("SELECT *, IF(drug_id > 0, drug_id, drug_id) AS id FROM drug WHERE drug_id <= $id LIMIT 50");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function get_min_id(){
        $statement = $this->database->prepare("SELECT MIN(drug_id) AS min_id FROM drug");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function get_max_id(){
        $statement = $this->database->prepare("SELECT MAX(drug_id) AS max_id FROM drug");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function search($sSearch, $limit = 50)
    {   
        $query = "SELECT *, IF(drug_id > 0, drug_id, drug_id) AS id FROM drug WHERE all_patients=1 AND name LIKE '%$sSearch%' LIMIT $limit";
        $statement = $this->database->prepare($query);
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function drug_frequency($limit = 100){
        $query = "SELECT *, IF(frequency_id > 0, frequency_id, frequency_id) AS id FROM drug_frequency LIMIT $limit";
        $statement = $this->database->prepare($query);
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }
}
