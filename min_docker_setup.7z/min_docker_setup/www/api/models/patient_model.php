<?php

class Patient_Model extends Model
{

    function __construct()
    {
        parent::__construct();
    }

    public function get_patient($id)
    {
        $statement = $this->database->prepare("SELECT *, IF(patient_id > 0, patient_id, patient_id) AS id FROM patient WHERE patient_id=$id");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC); // set pdo object to fetch associative/named array only.
        return $statement->fetchAll();
    }

    public function paginate_forward($id = 0)
    {
        $statement = $this->database->prepare("SELECT *, IF(patient_id > 0, patient_id, patient_id) AS id FROM patient WHERE patient_id >= $id LIMIT 50");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC); // set pdo object to fetch associative/named array only.
        return $statement->fetchAll();
    }

    public function paginate_backward($id)
    {
        $statement = $this->database->prepare("SELECT *, IF(patient_id > 0, patient_id, patient_id) AS id FROM patient WHERE patient_id <= $id LIMIT 50");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC); // set pdo object to fetch associative/named array only.
        return $statement->fetchAll();
    }

    public function get_min_id(){
        $statement = $this->database->prepare("SELECT MIN(patient_id) AS min_id FROM patient");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC); // set pdo object to fetch associative/named array only.
        return $statement->fetchAll();
    }

    public function get_max_id(){
        $statement = $this->database->prepare("SELECT MAX(patient_id) AS max_id FROM patient");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC); // set pdo object to fetch associative/named array only.
        return $statement->fetchAll();
    }
}

?>