<?php

class Test_Model extends Model
{

    function __construct()
    {
        parent::__construct();
    }

    public function get_test($id)
    {
        $statement = $this->database->prepare("SELECT *, IF(test_id > 0, test_id, test_id) AS id  FROM test WHERE test_id=$id");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function paginate_forward($id = 0)
    {
        $statement = $this->database->prepare("SELECT *, IF(test_id > 0, test_id, test_id) AS id FROM test WHERE test_id >= $id LIMIT 50");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function paginate_backward($id)
    {
        $statement = $this->database->prepare("SELECT *, IF(test_id > 0, test_id, test_id) AS id FROM test WHERE test_id <= $id LIMIT 50");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function get_min_id(){
        $statement = $this->database->prepare("SELECT MIN(test_id) AS min_id FROM test");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function get_max_id(){
        $statement = $this->database->prepare("SELECT MAX(test_id) AS max_id FROM test");
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }

    public function search($sSearch, $limit = 50)
    {   
        $query = "SELECT *, IF(test_id > 0, test_id, test_id) AS id FROM test WHERE name LIKE '%$sSearch%' LIMIT $limit";
        $statement = $this->database->prepare($query);
        $statement->execute();
        $statement->setFetchMode(PDO::FETCH_ASSOC);
        return $statement->fetchAll();
    }
}
