<?php
// phpinfo();
$handle = @fopen("myfields.txt", "r");
$count = 0;
$programFields = [
    'allPrograms' => [],
    'promo'=>[],
    'editorial'=>[],
    'partners'=>[],
    'medscape' => [],
];


$originalViewData = [
    'initProgramDetails' => [
        'bOUSProgram'=> 0,
        'bRetired'=> 0,
        'iCGMode'=> 0,
        'iLaunchDate'=> '',
        'sCondition'=> '',
        'sProgram'=> '',
        'sTempUnit'=> 'f',
    ],

    'initMedscapeDetails' => [
        'sProgramName'=> '',
        'sLanguage'=> 'en',
        'sGuidelinesTitle'=> 'NONE',
        'sWelcomeMsgTitle'=> 'NONE',
        'sArticleUrl'=> 'NONE',
        'sSalesforceNumber'=> '',
        'sTestDisclaimerTitle'=> '',
        'sQuestUrl'=> 'NONE',
        'sTheme'=> '',
        'sGuidelines'=> 'NONE',
        'sWelcomeMsg'=> 'NONE',
        'sTestDisclaimer'=> '',
        ///
        'bHideProductInfo'=> false,
        'bHideDosingInfo'=> false,
        'bHideDCI'=> false,
        'bHideDDI'=> false,
        'bHideDosageRange'=> false,
        'bHideHeadshot'=> false,
        'bShowImperialMeasuments'=> false,
        'bHidePrescriptionPad'=> false,
        'bShowHistoricalReports'=> false,
        'bEnableTestGroups'=> false,
        'bDownloadLiterature'=> false,
        'bSkipWaitingRoom'=> false,
        'bDisableDrugs'=> false,
        'bGlobalProgram'=> false,
    ],

    'initLiteratureReviewDetails' => [
        'sLiteratureReview'=> '',
        'sLiteratureLabel'=> '',
    ],

    'initGuidanceDetails' => [
        'sGuidanceAppropriate'=> 'Appropriate Action: Well Done!',
        'sGuidanceContraindicated'=> 'Contraindicated',
        'sGuidanceDosage'=> 'Appropriate Drug/Incorrect Dosage',
        'sGuidanceError'=> 'Yikes, Severe Error!',
        'sGuidanceInfo'=> 'Information provided for your benefit',
        'sGuidanceMistake'=> 'Significant Error',
        'sGuidanceReview'=> 'Consider a Different Selection',
        'sGuidanceWarning'=> "Hmmm, Something doesn't look right...",
    ],

    'initSurveyDetails' => [
        'aSurveyOptions' => '',
        'sSurveyQuestion'=> '',
    ],

    'initSimSubSection' => [
        'sIntroFamilySocialTitle'=> 'Family and Social History',
        'sIntroHpiTitle'=> 'History of Present Illness',
        'sIntroPhysicalExamTitle'=> 'Physical Examination Notes',
        'sOrdersMedicationTitle'=> 'Add Medications',
        'sOrdersNonMedicationOrdersTitle'=> 'Add Non-Medication Orders',
    ],
    
    'initChartSubSection' => [
        'sChartCaseDescriptionTitle'=> 'Case Description',
        'sChartConditionHistoryTitle'=> 'Condition History',
        'sChartMedicationHistoryTitle'=> 'Medication History',
        'sChartPastTestsTitle'=> 'Past Tests',
        'sChartPastVisitsTitle'=> 'Past Visits',
        'sChartTodayDiagnosesTitle'=> "Today's Diagnoses",
        'sChartTodayOrdersTitle'=> "Today's Orders",
        'sChartTodayOtherOrdersTitle'=> 'Non Medication Orders/Consults',
        'sChartTodayTestsTitle'=> "Today's Tests",
    ],

    'initCaseReview' => [
        'sClosingLabel'=> 'Closing Remarks',
        'sLiteratureLabel'=> 'Literature Review',
        'sPeerLabel'=> 'Peer Stats',
        'sPerformanceLabel'=> 'Performance Analysis',
    ],

    'initCaseComplete' => [
        'sPostSimBtnLabel'=> 'Earn CME Credit',
        'sPostSimContent'=> 'You have completed all the simulations!',
        'sPostSimTitle'=> 'Congratulations!',
    ]
];


// keys in specific views. the current view is CME config
$views = [
    'initProgramDetails' => [
        'bOUSProgram'=> 0,
        'bRetired'=> 0,
        'iCGMode'=> 0,
        'iLaunchDate'=> '',
        'sCondition'=> '',
        'sProgram'=> '',
        'sTempUnit'=> 'f',
        'sSimVersion' => ''
    ],
    'initMedscapeDetails' => [
        'sChiefEditorDescription' => '',
        'sChiefEditorPreview' => '',
        'sResourcesLabel' => '',
        'sResources' => '',
        'sProgramName'=> '',
        'sLanguage'=> 'en',
        'sGuidelinesTitle'=> 'NONE',
        'sWelcomeMsgTitle'=> 'NONE',
        'sArticleUrl'=> 'NONE',
        'sSalesforceNumber'=> '',
        'sTestDisclaimerTitle'=> '',
        'sQuestUrl'=> 'NONE',
        'sMedicationGuideTitle' => '',
        'sMedicationGuideUrl' => '',
        'sMedscapeUrl' => '',
        'sPixelTrackUrl' => '',
        'sPrescribingInfoTitle' => '',
        'sPrescribingInfoUrl' => '',
        'sSponsor' => '',
        'sSupporterDrug' => '',
        'sWelcomeMessage' => '',
        'sSupporterISITitle' => '',
        'sSupporterISIUrl' => '',
        'sProjectInfo' => '',
        'sTheme'=> '',
        'sGuidelines'=> 'NONE',
        'sWelcomeMsg'=> 'NONE',
        'sTestDisclaimer'=> '',
        'bHideProductInfo'=> false,
        'bHideDosingInfo'=> false,
        'bHideDCI'=> false,
        'bHideDDI'=> false,
        'bHideDosageRange'=> false,
        'bHideHeadshot'=> false,
        'bShowImperialMeasuments'=> false,
        'bHidePrescriptionPad'=> false,
        'bShowHistoricalReports'=> false,
        'bEnableTestGroups'=> false,
        'bDownloadLiterature'=> false,
        'bSkipWaitingRoom'=> false,
        'bDisableDrugs'=> false,
        'bGlobalProgram'=> false,
        'bDisableGraphs' => false,
        'bDxOrders' => false,
        'bPromoted' => false,
        'bSkipMobile' => false,
        'bHideBmi' => false,
        'bIncludeAds' => false,
        'bUseInlineTherapies' => false,
        'sDevelopmentInfo' => '',
        'sImportantSafetyInfo' => '',
        'sImportantSafetyInfo2' => '',
              
    ],

    'initLiteratureReviewDetails' => [
        'sLiteratureReview'=> '',
        'sLiteratureLabel'=> '',
    ],

    'initSimSubSection' => [
        'sIntroFamilySocialTitle'=> 'Family and Social History',
        'sIntroHpiTitle'=> 'History of Present Illness',
        'sIntroPhysicalExamTitle'=> 'Physical Examination Notes',
        'sOrdersMedicationTitle'=> 'Add Medications',
        'sOrdersNonMedicationOrdersTitle'=> 'Add Non-Medication Orders',
    ],
    'initChartSubSection' => [
        'sChartCaseDescriptionTitle'=> 'Case Description',
        'sChartConditionHistoryTitle'=> 'Condition History',
        'sChartMedicationHistoryTitle'=> 'Medication History',
        'sChartPastTestsTitle'=> 'Past Tests',
        'sChartPastVisitsTitle'=> 'Past Visits',
        'sChartTodayDiagnosesTitle'=> "Today's Diagnoses",
        'sChartTodayOrdersTitle'=> "Today's Orders",
        'sChartTodayOtherOrdersTitle'=> 'Non Medication Orders/Consults',
        'sChartTodayTestsTitle'=> "Today's Tests",
        'sChartDiagnosesTitle' => '',
        'sChartOrdersTitle' => '',
        'sChartTestsTitle' => '',
        'sChartTitle' => '',
        'sChartVisitsTitle' => '',
        'sChartDemographicsTitle' => '',  
    ],
    'initCaseReview' => [
        'sClosingLabel'=> 'Closing Remarks',
        'sLiteratureLabel'=> 'Literature Review',
        'sPeerLabel'=> 'Peer Stats',
        'sPerformanceLabel'=> 'Performance Analysis',
    ],

    'initCaseComplete' => [
        'sPostSimBtnLabel'=> 'Earn CME Credit',
        'sPostSimContent'=> 'You have completed all the simulations!',
        'sPostSimTitle'=> 'Congratulations!',
    ],

    'initGuidanceDetails' => [
        'sGuidanceAppropriate'=> 'Appropriate Action: Well Done!',
        'sGuidanceContraindicated'=> 'Contraindicated',
        'sGuidanceDosage'=> 'Appropriate Drug/Incorrect Dosage',
        'sGuidanceError'=> 'Yikes, Severe Error!',
        'sGuidanceInfo'=> 'Information provided for your benefit',
        'sGuidanceMistake'=> 'Significant Error',
        'sGuidanceReview'=> 'Consider a Different Selection',
        'sGuidanceWarning'=> "Hmmm, Something doesn't look right...",
    ],

    'initSurveyDetails' => [
        'aSurveyOptions'=> '',
        'sSurveyQuestion'=> '',
    ]


];

function allKeys($namedArray){
    $allKeys = [];
    $keys = array_keys ($namedArray);
    
    foreach($namedArray as $key){
        foreach($key as $dataKey => $val){
            $allKeys[$dataKey] = [];

            for( $i = 0; $i < count($keys); $i++){
                $currKey = $keys[$i];
                if (array_key_exists($dataKey,$namedArray[$currKey])){
                    $allKeys[$dataKey][$currKey] = true;
                }
            }
        }
    }


    return $allKeys;
}

function getZeroView($data){
    $dataKeys = array_keys ($data); // promo, editorial, ect...
    $newData = [];
    for($i = 0; $i < count($dataKeys); $i++){
        $program = $dataKeys[$i];
        $currentArray= array_keys ($data[$program]);
        for($x = 0; $x < count($currentArray); $x++){
                if(!$data[$program][$currentArray[$x]]['numberOfViews']){
                    //$newData[$currentArray[$x]] = $keys[$i];
                    $newData[$currentArray[$x]][$program] = 1;
                    //array_push($newData[$currentArray[$x]],$program);
                }
        }

    }
    return $newData;

}

// combines keys from 2 different arrays.
function eric($name1,$name2,$array,$views = []){
    $data = [];
    $viewKeys = array_keys ($views);
    $hasKeys = count($viewKeys);
    

    for($i = 0; $i < count($array[$name1]); $i++){
        $field = $array[$name1][$i]['field'];
        $label = $array[$name1][$i]['label'];
        $default = $array[$name1][$i]['defaultValue'];
        $data[$field] = ['label' => $label, 'defaultValue' => $default,'numberOfViews' => 0, 'views' => []];
        if(!$hasKeys){
            continue;
        }

        for( $x = 0; $x < $hasKeys; $x++){
            $currentView = $viewKeys[$x];

            if (array_key_exists($field,$views[$currentView])){
                array_push($data[$field]['views'], $currentView);
                $data[$field]['numberOfViews'] = count($data[$field]['views']);
            }

        }
    }

    for($i = 0; $i < count($array[$name2]); $i++){
        $field = $array[$name2][$i]['field'];
        $label = $array[$name2][$i]['label'];
        $default = $array[$name1][$i]['defaultValue'];
        $data[$field] = ['label' => $label, 'defaultValue' => $default,'numberOfViews' => 0, 'views' => []];
        if(!$hasKeys){
            continue;
        }

        for( $x = 0; $x < $hasKeys; $x++){
            $currentView = $viewKeys[$x];

            if (array_key_exists($field,$views[$currentView])){
                array_push($data[$field]['views'], $currentView);
                $data[$field]['numberOfViews'] = count($data[$field]['views']);
            }

        }
    }

    return $data;
}

// gets all fields according to program
if ($handle) {
    while (($buffer = fgets($handle, 4096)) !== false) {
        if($count > 0){
            
            
            $row = explode(';',$buffer);
            $type_id = $row[0];
            //print_r($row);
            $rowData = [
                'field' => $row[2],
                'label' => $row[3],
                'position' => $row[4],
                'defaultValue' => $row[5],
                'views' => []
            ];
            if($type_id == '3'){
               array_push($programFields['allPrograms'],$rowData);
                
            }

            if($type_id == '4'){
                array_push($programFields['medscape'],$rowData); 
             }

             if($type_id == '6'){
                array_push($programFields['promo'],$rowData); 
             }

            if($type_id == '9'){
                array_push($programFields['editorial'],$rowData);
             }

             if($type_id == '10'){
                array_push($programFields['partners'],$rowData); 
             }
  
        }
        $count=1;
        //echo $buffer . '<br/><br/>';
    }
    if (!feof($handle)) {
        echo "Error: unexpected fgets() fail\n";
    }
    fclose($handle);

    // echo json_encode($programFields);
    echo '<pre>';
    //print_r($programFields['allPrograms']);
    echo '</pre>';
    

   

    // programs with default values.$views
    $newDataKeys = [
    'promo' => eric('allPrograms','promo',$programFields,$views),
        'editorial' => eric('allPrograms','editorial',$programFields,$views),
      'partners' => eric('allPrograms','partners',$programFields,$views),
       'medscape' => eric('allPrograms','medscape',$programFields,$views)
    ];

    //  echo '<pre>';
    //  print_r(getZeroView($newDataKeys));
    //  echo '</pre>';
    

    $newProgramsWithFields = ['cme' => $originalViewData];
    $outerKeys = array_keys ($newDataKeys);
    
    for( $z = 0; $z < count($outerKeys); $z++){
        $programType = $outerKeys[$z]; // promo, editorial, partners, and medscape.
        $current = $newDataKeys[$programType]; // get current array by key.
        
        $fields = array_keys ($current); // list of fields with label, defaultValue, views: []
        for( $x = 0; $x < count($fields); $x++){
            $currentKey = $fields[$x];
            $currentLabel = $current[$currentKey]['label'];
            $currentdefaultValue = $current[$currentKey]['defaultValue'];
            $currentViews = $current[$currentKey]['views'];

            for( $g = 0; $g < count($currentViews); $g++){
                $currentView = $currentViews[$g];
                // create an array i.e [promo][initMedscapeDetails][key] = value
                $newProgramsWithFields[$programType][$currentView][$currentKey] = $currentdefaultValue;
            }

        }
    }
    

    // echo json_encode($newProgramsWithFields);
    //file_put_contents ('erics_program.json', json_encode($newProgramsWithFields));
   echo '<pre>';
    //print_r($newProgramsWithFields['promo']);
    print_r($newDataKeys['promo']);
    



    // print_r(array_keys (eric('allPrograms','medscape',$programFields,$views)));
    echo '</pre>';
    //echo json_encode(allKeys($newDataKeys));


    /*
    var dan = document.querySelectorAll('input[type="checkbox"]');
    for(let i = 0; i < dan.length; i++){
        console.log(dan[i].getAttribute('data-map'));
    }
    */

    $me = ['sLiteratureReview'=> '',
    'iCGMode' => '',
    'bDxOrders' => '',
    'sSalesforceNumber' => '',
    'sTheme' => '',
    'bDisableDrugs' => '',
    'bDisableGraphs' => '',
    'bSkipWaitingRoom' => '',
    'sProgramName' => '',
    'bPromoted' => '',
    'sGuidanceInfo' => '',
    'sGuidanceAppropriate' => '',
    'sGuidanceWarning' => '',
    'sGuidanceError' => '',
    'sGuidanceMistake'=> '',
    'sGuidanceContraindicated'=> '',
    'sSimVersion'=> '',
    'sClosingLabel'=> '',
    'sLiteratureLabel'=> '',
    'sPerformanceLabel'=> '',
    'sPeerLabel'=> '',
    'bDownloadLiterature' => '',
    'sTempUnit'=> '',
    'bHideProductInfo' => '',
    'bHideDosingInfo' => '',
    'bHideDCI' => '',
    'bHideDDI' => '',
    'bHideDosageRange' => '',
    'sLanguage'=> '',
    'sMediaVersion'=> '',
    'bGlobalProgram' => '',
    'sTestDisclaimer'=> '',
    'sTestDisclaimerTitle'=> '',
    'sPostSimTitle'=> '',
    'sPostSimContent'=> '',
    'sPostSimBtnLabel'=> '',
    'sCustomCss'=> '',
    'bOUSProgram' => '',
    'bHideHeadshot' => '',
    'bShowImperialMeasuments' => '',
    'bHidePrescriptionPad' => '',
    'sGuidanceDosage' => '',
    'sChartTitle' => '',
    'sChartCaseDescriptionTitle' => '',
    'sChartPastVisitsTitle' => '',
    'sChartPastTestsTitle' => '',
    'sChartConditionHistoryTitle' => '',
    'sChartMedicationHistoryTitle' => '',
    'sChartTodayTestsTitle' => '',
    'sChartTodayDiagnosesTitle' => '',
    'sChartTodayOrdersTitle' => '',
    'sChartTodayOtherOrdersTitle' => '',
    'sChartDemographicsTitle' => '',
    'sChartVisitsTitle' => '',
    'sChartTestsTitle' => '',
    'sChartDiagnosesTitle' => '',
    'sChartOrdersTitle' => '',
    'sIntroHpiTitle' => '',
    'sIntroFamilySocialTitle' => '',
    'sIntroPhysicalExamTitle' => '',
    'sOrdersMedicationTitle' => '',
    'sOrdersNonMedicationOrdersTitle' => '',
    'bShowHistoricalReports' => '',
    'sGuidanceReview' => '',
    'bEnableTestGroups' => ''];

    $dan245 = array_keys($me);
    for($x = 0; $x < count($dan245); $x++){
        echo $dan245[$x] . '<br/>';
    }
    
}
?>