<?php
require './vendor/autoload.php';
use \Firebase\JWT\JWT;

$key = "example_key"; // secret key
$iss = "localhost";
$iat = time();
$nbf = $iat + 10;
$exp = $iat + (60 * 60);
$aud = 'myusers';
$data = [ 'user_id' => 1];

$payload = array(
    "iss" => $iss,
    "aud" => $aud,
    "iat" => $iat,
    "nbf" => $nbf,
    "exp" => $exp,
    "data" => $data
);

/**
 * IMPORTANT:
 * You must specify supported algorithms for your application. See
 * https://tools.ietf.org/html/draft-ietf-jose-json-web-algorithms-40
 * for a list of spec-compliant algorithms.
 */
$jwt = JWT::encode($payload, $key);
echo $jwt;
try{
    $decoded = JWT::decode($jwt,$key, array('HS256'));

echo '<br />';
print_r($decoded);

/*
 NOTE: This will now be an object instead of an associative array. To get
 an associative array, you will need to cast it as such:
*/

$decoded_array = (array) $decoded;

/**
 * You can add a leeway to account for when there is a clock skew times between
 * the signing and verifying servers. It is recommended that this leeway should
 * not be bigger than a few minutes.
 *
 * Source: http://self-issued.info/docs/draft-ietf-oauth-json-web-token.html#nbfDef
 */
JWT::$leeway = 60; // $leeway in seconds
$decoded = JWT::decode($jwt, $key, array('HS256'));
}catch(Exception $e){
    echo $e->getMessage();
}

?>